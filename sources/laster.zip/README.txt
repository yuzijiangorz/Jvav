It's just a joke, but we still make it, and the joke was first brought by Zhang Haoyang.
Its reprints comply with the CC3.0 protocol.

By 30266
2020-04-16 11:00(UTC)